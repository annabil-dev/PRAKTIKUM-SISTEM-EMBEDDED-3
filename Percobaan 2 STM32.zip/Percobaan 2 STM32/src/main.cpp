#include <Arduino.h>

// LED outputs:
// - Keep external LEDs on PA4/PA5
// Hardware buttons (active-low with INPUT_PULLUP)
#define LED1_PIN PA4
#define LED2_PIN PA5
#define BTN1_PIN PB12
#define BTN2_PIN PB13

bool led1On = false;
bool led2On = false;
bool btn1Pressed = false;
bool btn2Pressed = false;
bool guiLed1On = false;
bool guiLed2On = false;
unsigned long lastStatus = 0;
const unsigned long statusInterval = 500;
const unsigned long cmdIdleFlushMs = 30;

String rxSerialBuffer;
unsigned long rxSerialLastByteMs = 0;

void printLineToActivePorts(const String& line) {
  Serial.println(line);
}

void sendStatus() {
  String status = "STATUS:L1:";
  status += (led1On ? "1" : "0");
  status += ",L2:";
  status += (led2On ? "1" : "0");
  status += ",B1:";
  status += (btn1Pressed ? "1" : "0");
  status += ",B2:";
  status += (btn2Pressed ? "1" : "0");
  printLineToActivePorts(status);
}

void applyLedState() {
  digitalWrite(LED1_PIN, led1On ? HIGH : LOW);
  digitalWrite(LED2_PIN, led2On ? HIGH : LOW);
}

void recomputeLedOutput(bool forceStatus) {
  bool nextLed1 = btn1Pressed || guiLed1On;
  bool nextLed2 = btn2Pressed || guiLed2On;

  bool ledChanged = (nextLed1 != led1On) || (nextLed2 != led2On);
  led1On = nextLed1;
  led2On = nextLed2;

  if (ledChanged) {
    applyLedState();
  }

  if (forceStatus || ledChanged) {
    sendStatus();
  }
}

void syncLedFromButtons() {
  bool currentBtn1 = (digitalRead(BTN1_PIN) == LOW);
  bool currentBtn2 = (digitalRead(BTN2_PIN) == LOW);

  // Detect press edge (HIGH→LOW): toggle the locked LED state.
  if (currentBtn1 && !btn1Pressed) {
    guiLed1On = !guiLed1On;
  }
  if (currentBtn2 && !btn2Pressed) {
    guiLed2On = !guiLed2On;
  }

  bool changed = (currentBtn1 != btn1Pressed) || (currentBtn2 != btn2Pressed);
  btn1Pressed = currentBtn1;
  btn2Pressed = currentBtn2;

  if (changed) {
    recomputeLedOutput(true);
  }
}

void blinkBothTemporary(uint8_t times, uint16_t onMs, uint16_t offMs) {
  bool prevLed1 = led1On;
  bool prevLed2 = led2On;

  for (uint8_t i = 0; i < times; i++) {
    led1On = true;
    led2On = true;
    applyLedState();
    sendStatus();
    delay(onMs);

    led1On = false;
    led2On = false;
    applyLedState();
    sendStatus();
    delay(offMs);
  }

  led1On = prevLed1;
  led2On = prevLed2;
  applyLedState();
  sendStatus();
}

void handleCommand(const String& cmd) {
  String normalized = cmd;
  normalized.trim();
  normalized.toUpperCase();

  if (normalized.length() == 0) {
    return;
  }

  if (normalized == "CONNECT") {
    blinkBothTemporary(1, 90, 90);
    printLineToActivePorts("ACK:CONNECT");
    sendStatus();
    return;
  }

  if (normalized == "DISCONNECT") {
    printLineToActivePorts("ACK:DISCONNECT");
    sendStatus();
    return;
  }

  if (normalized == "BLINK") {
    blinkBothTemporary(2, 120, 120);
    printLineToActivePorts("ACK:BLINK");
    printLineToActivePorts("BLINK_DONE");
    sendStatus();
    return;
  }

  if (normalized == "L1:ON" || normalized == "L1ON") {
    guiLed1On = true;
  } else if (normalized == "L1:OFF" || normalized == "L1OFF") {
    guiLed1On = false;
  } else if (normalized == "L1:TOGGLE" || normalized == "L1" || normalized == "L1TOGGLE") {
    guiLed1On = !guiLed1On;
  } else if (normalized == "L2:ON" || normalized == "L2ON") {
    guiLed2On = true;
  } else if (normalized == "L2:OFF" || normalized == "L2OFF") {
    guiLed2On = false;
  } else if (normalized == "L2:TOGGLE" || normalized == "L2" || normalized == "L2TOGGLE") {
    guiLed2On = !guiLed2On;
  } else {
    printLineToActivePorts("ACK:UNKNOWN");
    return;
  }

  recomputeLedOutput(true);
  printLineToActivePorts("ACK:" + normalized);
}

void readPortCommands(Stream& port, String& rxBuffer, unsigned long& lastByteMs) {
  while (port.available()) {
    char c = static_cast<char>(port.read());
    lastByteMs = millis();

    if (c == '\r') {
      continue;
    }

    if (c == '\n') {
      if (rxBuffer.length() > 0) {
        handleCommand(rxBuffer);
        rxBuffer = "";
      }
      continue;
    }

    if (rxBuffer.length() < 64) {
      rxBuffer += c;
    }
  }
}

void flushStaleCommandBuffer(String& rxBuffer, unsigned long lastByteMs) {
  if (rxBuffer.length() == 0) {
    return;
  }

  if (millis() - lastByteMs >= cmdIdleFlushMs) {
    handleCommand(rxBuffer);
    rxBuffer = "";
  }
}

void readSerialCommands() {
  readPortCommands(Serial, rxSerialBuffer, rxSerialLastByteMs);
  flushStaleCommandBuffer(rxSerialBuffer, rxSerialLastByteMs);
}

void setup() {
  Serial.begin(115200);
  pinMode(LED1_PIN, OUTPUT);
  pinMode(LED2_PIN, OUTPUT);
  pinMode(BTN1_PIN, INPUT_PULLUP);
  pinMode(BTN2_PIN, INPUT_PULLUP);

  btn1Pressed = (digitalRead(BTN1_PIN) == LOW);
  btn2Pressed = (digitalRead(BTN2_PIN) == LOW);
  guiLed1On = false;
  guiLed2On = false;
  recomputeLedOutput(false);

  blinkBothTemporary(1, 80, 80);
  printLineToActivePorts("READY:STM32");
  sendStatus();
}

void loop() {
  readSerialCommands();
  unsigned long now = millis();
  syncLedFromButtons();

  // Kirim status berkala ke GUI
  if (now - lastStatus >= statusInterval) {
    lastStatus = now;
    sendStatus();
  }
}
