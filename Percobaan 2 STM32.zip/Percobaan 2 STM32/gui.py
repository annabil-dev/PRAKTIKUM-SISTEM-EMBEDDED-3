import tkinter as tk
import customtkinter as ctk
import serial
import serial.tools.list_ports
import threading
import time
import queue

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ===== Color Palette =====
BG_DARK = "#1e1e2e"
BG_CARD = "#2a2a3d"
BG_HEADER = "#252538"
TEXT_PRIMARY = "#cdd6f4"
TEXT_SECONDARY = "#a6adc8"
ACCENT_BLUE = "#5b8bd4"
ACCENT_GREEN = "#6bc46d"
ACCENT_RED = "#e35b5b"
ACCENT_YELLOW = "#e5c07b"
LED_ON = "#6bc46d"
LED_OFF = "#3a3a4e"
BTN_ON = "#5b8bd4"
BTN_OFF = "#3a3a4e"


class STM32GUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("STM32 LED Controller - Percobaan 2")
        self.geometry("980x760")
        self.resizable(False, False)
        self.configure(fg_color=BG_DARK)

        self.serial_conn = None
        self.connected = False
        self.running = True
        self.read_thread = None
        self.write_thread = None
        self._io_lock = threading.Lock()
        self._connect_in_progress = False
        self._last_status_ts = 0.0
        self._awaiting_handshake = False
        self._handshake_retries = 0
        self._handshake_ok = False
        self._tx_queue = queue.Queue()

        # State
        self.led1_state = False
        self.led2_state = False
        self.btn1_state = False
        self.btn2_state = False

        self._pending_status = None  # throttle UI updates

        self._build_ui()
        self._set_led_controls_enabled(False)
        self._poll_status()  # Start one UI polling loop for the app lifetime
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ===== Build UI =====
    def _build_ui(self):
        # Header
        header = ctk.CTkFrame(self, fg_color=BG_HEADER, corner_radius=0, height=55)
        header.pack(fill="x")
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="STM32 LED Controller",
                     font=ctk.CTkFont(size=20, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(side="left", padx=20, pady=12)

        # Connection status dot
        self.conn_dot = ctk.CTkLabel(header, text="\u25cf", font=ctk.CTkFont(size=16),
                                     text_color=ACCENT_RED)
        self.conn_dot.pack(side="right", padx=(0, 8), pady=12)
        self.conn_label = ctk.CTkLabel(header, text="Disconnected",
                                       font=ctk.CTkFont(size=12),
                                       text_color=TEXT_SECONDARY)
        self.conn_label.pack(side="right", pady=12)

        # Main container
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=20, pady=15)
        container.grid_columnconfigure(0, weight=3)
        container.grid_columnconfigure(1, weight=2)
        container.grid_rowconfigure(0, weight=1)

        left_panel = ctk.CTkFrame(container, fg_color="transparent")
        left_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        right_panel = ctk.CTkFrame(container, fg_color="transparent")
        right_panel.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        right_panel.grid_rowconfigure(0, weight=1)
        right_panel.grid_columnconfigure(0, weight=1)

        # ---- Connection Card ----
        conn_card = ctk.CTkFrame(left_panel, fg_color=BG_CARD, corner_radius=12)
        conn_card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(conn_card, text="Serial Connection",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(anchor="w", padx=16, pady=(12, 6))

        conn_row = ctk.CTkFrame(conn_card, fg_color="transparent")
        conn_row.pack(fill="x", padx=16, pady=(0, 12))

        self.port_combo = ctk.CTkComboBox(conn_row, width=240, values=self._get_ports(),
                                          fg_color=BG_DARK, border_color="#3a3a4e",
                                          button_color=ACCENT_BLUE,
                                          dropdown_fg_color=BG_DARK,
                                          text_color=TEXT_PRIMARY)
        self.port_combo.pack(side="left", padx=(0, 8))

        # Auto-detect STM32 port on startup
        stm_port = self._find_stm32_port()
        if stm_port:
            self.port_combo.set(stm_port)
        elif self.port_combo.cget("values"):
            self.port_combo.set(self.port_combo.cget("values")[0])
        else:
            self.port_combo.set("No ports found")

        ctk.CTkButton(conn_row, text="\u21bb", width=36,
                       fg_color=BG_DARK, hover_color="#3a3a4e",
                       text_color=TEXT_SECONDARY,
                       command=self._refresh_ports).pack(side="left", padx=(0, 8))

        self.connect_btn = ctk.CTkButton(conn_row, text="Connect", width=100,
                                         fg_color=ACCENT_BLUE,
                                         hover_color="#4a7ac3",
                                         text_color="#ffffff",
                                         command=self._toggle_connection)
        self.connect_btn.pack(side="left")

        # ---- LED Control Card ----
        led_card = ctk.CTkFrame(left_panel, fg_color=BG_CARD, corner_radius=12)
        led_card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(led_card, text="LED Control",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(anchor="w", padx=16, pady=(12, 8))

        led_row = ctk.CTkFrame(led_card, fg_color="transparent")
        led_row.pack(fill="x", padx=16, pady=(0, 14))
        led_row.columnconfigure((0, 1), weight=1)

        # LED 1
        led1_frame = ctk.CTkFrame(led_row, fg_color=BG_DARK, corner_radius=10)
        led1_frame.grid(row=0, column=0, padx=(0, 6), sticky="ew")

        ctk.CTkLabel(led1_frame, text="LED 1",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(pady=(12, 4))

        self.led1_indicator = ctk.CTkLabel(led1_frame, text="\u25cf",
                                           font=ctk.CTkFont(size=40),
                                           text_color=LED_OFF)
        self.led1_indicator.pack(pady=4)

        self.led1_status = ctk.CTkLabel(led1_frame, text="OFF",
                                        font=ctk.CTkFont(size=11),
                                        text_color=TEXT_SECONDARY)
        self.led1_status.pack()

        self.led1_btn = ctk.CTkButton(led1_frame, text="Toggle LED 1",
                                      fg_color=ACCENT_BLUE,
                                      hover_color="#4a7ac3",
                                      text_color="#ffffff",
                                      command=lambda: self._toggle_led(1))
        self.led1_btn.pack(padx=16, pady=(8, 14))

        # LED 2
        led2_frame = ctk.CTkFrame(led_row, fg_color=BG_DARK, corner_radius=10)
        led2_frame.grid(row=0, column=1, padx=(6, 0), sticky="ew")

        ctk.CTkLabel(led2_frame, text="LED 2",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(pady=(12, 4))

        self.led2_indicator = ctk.CTkLabel(led2_frame, text="\u25cf",
                                           font=ctk.CTkFont(size=40),
                                           text_color=LED_OFF)
        self.led2_indicator.pack(pady=4)

        self.led2_status = ctk.CTkLabel(led2_frame, text="OFF",
                                        font=ctk.CTkFont(size=11),
                                        text_color=TEXT_SECONDARY)
        self.led2_status.pack()

        self.led2_btn = ctk.CTkButton(led2_frame, text="Toggle LED 2",
                                      fg_color=ACCENT_BLUE,
                                      hover_color="#4a7ac3",
                                      text_color="#ffffff",
                                      command=lambda: self._toggle_led(2))
        self.led2_btn.pack(padx=16, pady=(8, 14))

        # ---- Hardware Button Status Card ----
        btn_card = ctk.CTkFrame(left_panel, fg_color=BG_CARD, corner_radius=12)
        btn_card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(btn_card, text="Hardware Buttons",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(anchor="w", padx=16, pady=(12, 8))

        btn_row = ctk.CTkFrame(btn_card, fg_color="transparent")
        btn_row.pack(fill="x", padx=16, pady=(0, 14))
        btn_row.columnconfigure((0, 1), weight=1)

        # Button 1 indicator
        btn1_frame = ctk.CTkFrame(btn_row, fg_color=BG_DARK, corner_radius=10)
        btn1_frame.grid(row=0, column=0, padx=(0, 6), sticky="ew")

        ctk.CTkLabel(btn1_frame, text="Push Button 1",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(pady=(12, 4))

        self.btn1_indicator = ctk.CTkLabel(btn1_frame, text="\u25cf",
                                           font=ctk.CTkFont(size=30),
                                           text_color=BTN_OFF)
        self.btn1_indicator.pack(pady=4)

        self.btn1_status = ctk.CTkLabel(btn1_frame, text="RELEASED",
                                        font=ctk.CTkFont(size=11),
                                        text_color=TEXT_SECONDARY)
        self.btn1_status.pack(pady=(0, 12))

        # Button 2 indicator
        btn2_frame = ctk.CTkFrame(btn_row, fg_color=BG_DARK, corner_radius=10)
        btn2_frame.grid(row=0, column=1, padx=(6, 0), sticky="ew")

        ctk.CTkLabel(btn2_frame, text="Push Button 2",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(pady=(12, 4))

        self.btn2_indicator = ctk.CTkLabel(btn2_frame, text="\u25cf",
                                           font=ctk.CTkFont(size=30),
                                           text_color=BTN_OFF)
        self.btn2_indicator.pack(pady=4)

        self.btn2_status = ctk.CTkLabel(btn2_frame, text="RELEASED",
                                        font=ctk.CTkFont(size=11),
                                        text_color=TEXT_SECONDARY)
        self.btn2_status.pack(pady=(0, 12))

        # ---- Event Log Card ----
        log_card = ctk.CTkFrame(left_panel, fg_color=BG_CARD, corner_radius=12)
        log_card.pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(log_card, text="Event Log",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(anchor="w", padx=16, pady=(12, 6))

        self.log_box = ctk.CTkTextbox(log_card, height=80, fg_color=BG_DARK,
                                      text_color=TEXT_SECONDARY,
                                      font=ctk.CTkFont(size=11),
                                      corner_radius=8, state="disabled")
        self.log_box.pack(fill="x", padx=16, pady=(0, 12))

        # ---- Serial Monitor Card ----
        serial_card = ctk.CTkFrame(right_panel, fg_color=BG_CARD, corner_radius=12)
        serial_card.grid(row=0, column=0, sticky="nsew")
        serial_card.grid_rowconfigure(1, weight=1)
        serial_card.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(serial_card, text="Serial Monitor (TX/RX)",
                 font=ctk.CTkFont(size=14, weight="bold"),
                 text_color=TEXT_PRIMARY).pack(anchor="w", padx=16, pady=(12, 6))

        self.serial_box = ctk.CTkTextbox(serial_card, height=170, fg_color=BG_DARK,
                         text_color=TEXT_SECONDARY,
                         font=ctk.CTkFont(size=11),
                         corner_radius=8, state="disabled")
        self.serial_box.pack(fill="both", expand=True, padx=16, pady=(0, 12))

    # ===== Serial Helpers =====
    _STM32_KEYWORDS = (
        "stm", "st-link", "stlink", "stmicroelectronics",
        "maple", "bluepill", "blue pill", "usb serial", "cdc",
        "ftdi", "ft232", "ch340", "cp210", "silicon labs", "wch",
        "1eaf", "0483",  # USB VID for Maple / STMicro
    )

    def _get_ports(self):
        ports = serial.tools.list_ports.comports()
        return [p.device for p in ports]

    def _find_stm32_port(self):
        """Return the first COM port that likely belongs to STM32."""
        # 1) Cari berdasarkan keyword
        for p in serial.tools.list_ports.comports():
            info = f"{p.description} {p.manufacturer or ''} {p.hwid or ''}".lower()
            if any(kw in info for kw in self._STM32_KEYWORDS):
                return p.device
        # 2) Fallback: ambil COM port pertama yang tersedia
        ports = serial.tools.list_ports.comports()
        if ports:
            return ports[0].device
        return None

    def _auto_connect(self):
        """Auto-detect dan langsung connect."""
        port = self._find_stm32_port()
        if port:
            self.port_combo.set(port)
            self._log(f"Auto-detected port: {port}")
            self._connect()
        else:
            self._log("No COM port found. Plug in STM32 and click Refresh.")

    def _refresh_ports(self):
        ports = self._get_ports()
        self.port_combo.configure(values=ports)
        stm_port = self._find_stm32_port()
        if stm_port:
            self.port_combo.set(stm_port)
            self._log(f"Detected port: {stm_port}")
        elif ports:
            self.port_combo.set(ports[0])
        else:
            self.port_combo.set("No ports found")
        self._log("Ports refreshed")

    def _toggle_connection(self):
        if self.connected:
            self._disconnect()
        else:
            self._connect()

    def _set_led_controls_enabled(self, enabled):
        state = "normal" if enabled else "disabled"
        self.led1_btn.configure(state=state)
        self.led2_btn.configure(state=state)

    def _connect(self):
        if self._connect_in_progress:
            return

        port = self.port_combo.get()
        if not port or port == "No ports found":
            self._log("No valid port selected")
            return

        self._connect_in_progress = True
        self.connect_btn.configure(state="disabled", text="Connecting...")
        self._log(f"Connecting to {port}...")

        def _do_connect():
            try:
                conn = serial.Serial(
                    port,
                    115200,
                    timeout=0.2,
                    write_timeout=None,
                    xonxoff=False,
                    rtscts=False,
                    dsrdtr=False,
                )
                # Best-effort DTR assert (useful for some CDC devices).
                # For FTDI UART this is optional and should not fail connection.
                try:
                    conn.dtr = True
                except Exception:
                    pass
                time.sleep(2)  # Wait for STM32 reset after serial open
                try:
                    conn.reset_input_buffer()
                except Exception:
                    pass
                self.serial_conn = conn
                self.connected = True

                def _on_connected():
                    self._connect_in_progress = False
                    self._handshake_ok = False
                    self.connect_btn.configure(state="normal", text="Disconnect",
                                              fg_color=ACCENT_RED, hover_color="#c94a4a")
                    self.conn_dot.configure(text_color=ACCENT_YELLOW)
                    self.conn_label.configure(text="Handshaking")
                    self._set_led_controls_enabled(False)
                    self._log(f"Connected to {port}")
                    self.read_thread = threading.Thread(target=self._serial_reader, daemon=True)
                    self.read_thread.start()
                    self.write_thread = threading.Thread(target=self._serial_writer, daemon=True)
                    self.write_thread.start()
                    self._send("CONNECT", repeats=1)
                    self._awaiting_handshake = True
                    self._handshake_retries = 0
                    self.after(1200, self._verify_handshake)

                self.after(0, _on_connected)
            except serial.SerialException as e:
                err_msg = str(e)
                self.after(0, lambda: [
                    setattr(self, "_connect_in_progress", False),
                    self.connect_btn.configure(state="normal", text="Connect",
                                              fg_color=ACCENT_BLUE, hover_color="#4a7ac3"),
                    self._log(f"Connection failed: {err_msg}"),
                ])

        threading.Thread(target=_do_connect, daemon=True).start()

    def _disconnect(self):
        self._connect_in_progress = False
        self._awaiting_handshake = False
        self._handshake_ok = False
        self.connected = False
        self.connect_btn.configure(state="disabled", text="Disconnecting...")
        try:
            self._tx_queue.put_nowait(None)
        except Exception:
            pass

        conn = self.serial_conn
        self.serial_conn = None

        def _do_disconnect():
            if conn and conn.is_open:
                try:
                    self._send("DISCONNECT", repeats=2)
                    time.sleep(1.5)
                except Exception:
                    pass
                try:
                    conn.close()
                except Exception:
                    pass

            def _on_disconnected():
                self.connect_btn.configure(state="normal", text="Connect",
                                          fg_color=ACCENT_BLUE, hover_color="#4a7ac3")
                self.conn_dot.configure(text_color=ACCENT_RED)
                self.conn_label.configure(text="Disconnected")
                self._set_led_controls_enabled(False)
                self._reset_indicators()
                self._log("Disconnected")

            self.after(0, _on_disconnected)

        threading.Thread(target=_do_disconnect, daemon=True).start()

    def _send(self, message, repeats=1):
        conn = self.serial_conn
        if not (conn and conn.is_open and self.connected):
            return

        for _ in range(max(1, repeats)):
            self._log_serial(f"TX: {message}")
            self._tx_queue.put(message)

    def _serial_writer(self):
        while self.running and self.connected:
            try:
                msg = self._tx_queue.get(timeout=0.2)
            except queue.Empty:
                continue

            if msg is None:
                break

            conn = self.serial_conn
            if not (conn and conn.is_open and self.connected):
                continue

            data = (msg + "\n").encode("utf-8")
            try:
                with self._io_lock:
                    conn.write(data)
                self.after(0, lambda m=msg: self._log_serial(f"TX OK: {m}"))
            except serial.SerialTimeoutException:
                self.after(0, lambda m=msg: self._log(f"Serial write timeout: {m}"))
            except Exception as e:
                err_msg = str(e)
                self.after(0, lambda em=err_msg, m=msg: self._log(f"Serial write failed ({m}): {em}"))

    def _verify_handshake(self):
        if not self.connected or not self._awaiting_handshake:
            return

        elapsed = time.time() - self._last_status_ts
        if elapsed <= 2.0:
            self._awaiting_handshake = False
            self._handshake_ok = True
            self.conn_dot.configure(text_color=ACCENT_GREEN)
            self.conn_label.configure(text="Connected")
            self._set_led_controls_enabled(True)
            self._log("STM32 handshake OK")
            self._send("BLINK", repeats=1)
            return

        if self._handshake_retries < 1:
            self._handshake_retries += 1
            self._log("No STATUS yet, waiting...")
            self.after(1200, self._verify_handshake)
            return

        self._awaiting_handshake = False
        self._handshake_ok = True
        self.conn_dot.configure(text_color=ACCENT_YELLOW)
        self.conn_label.configure(text="Connected (No STATUS)")
        self._set_led_controls_enabled(True)
        self._log("No STATUS response yet. Staying connected (FTDI mode) - check RX wiring for telemetry.")

    # ===== Serial Reader Thread =====
    def _serial_reader(self):
        while self.connected and self.running:
            try:
                conn = self.serial_conn
                if conn and conn.is_open:
                    line = conn.readline().decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue
                    self.after(0, lambda msg=line: self._log_serial(f"RX: {msg}"))
                    if line.startswith("STATUS:"):
                        self._parse_status(line)
                    elif line.startswith("ACK:"):
                        self.after(0, lambda msg=line: self._log(msg))
                    elif line.startswith("READY:"):
                        self._last_status_ts = time.time()
                    elif line == "BLINK_DONE":
                        self.after(0, lambda: self._log("Blink sequence done"))
            except Exception:
                break

        # Kalau thread selesai karena error, update UI
        if self.connected:
            self.connected = False
            self._handshake_ok = False
            self.after(0, lambda: [
                self.connect_btn.configure(state="normal", text="Connect",
                                          fg_color=ACCENT_BLUE, hover_color="#4a7ac3"),
                self.conn_dot.configure(text_color=ACCENT_RED),
                self.conn_label.configure(text="Disconnected"),
                self._set_led_controls_enabled(False),
                self._reset_indicators(),
                self._log("Connection lost"),
            ])

    def _parse_status(self, line):
        # FORMAT: STATUS:L1:x,L2:x,B1:x,B2:x
        try:
            data = line[7:]  # remove "STATUS:"
            parts = {}
            for item in data.split(","):
                key, val = item.split(":")
                parts[key] = val == "1"

            l1 = parts.get("L1", False)
            l2 = parts.get("L2", False)
            b1 = parts.get("B1", False)
            b2 = parts.get("B2", False)

            # Simpan status terbaru, UI update di-throttle
            self._last_status_ts = time.time()
            if self.connected and not self._handshake_ok:
                self._handshake_ok = True
                self.after(0, lambda: [
                    self.conn_dot.configure(text_color=ACCENT_GREEN),
                    self.conn_label.configure(text="Connected"),
                    self._set_led_controls_enabled(True),
                    self._log("STM32 handshake OK"),
                ])
            self._pending_status = (l1, l2, b1, b2)
        except (ValueError, KeyError):
            pass

    # ===== UI Updates =====
    def _update_indicators(self, l1, l2, b1, b2):
        self.led1_state = l1
        self.led2_state = l2
        self.btn1_state = b1
        self.btn2_state = b2

        # LED indicators
        self.led1_indicator.configure(text_color=LED_ON if l1 else LED_OFF)
        self.led1_status.configure(text="ON" if l1 else "OFF",
                                   text_color=ACCENT_GREEN if l1 else TEXT_SECONDARY)

        self.led2_indicator.configure(text_color=LED_ON if l2 else LED_OFF)
        self.led2_status.configure(text="ON" if l2 else "OFF",
                                   text_color=ACCENT_GREEN if l2 else TEXT_SECONDARY)

        # Button indicators
        self.btn1_indicator.configure(text_color=BTN_ON if b1 else BTN_OFF)
        self.btn1_status.configure(text="PRESSED" if b1 else "RELEASED",
                                   text_color=ACCENT_BLUE if b1 else TEXT_SECONDARY)

        self.btn2_indicator.configure(text_color=BTN_ON if b2 else BTN_OFF)
        self.btn2_status.configure(text="PRESSED" if b2 else "RELEASED",
                                   text_color=ACCENT_BLUE if b2 else TEXT_SECONDARY)

    def _poll_status(self):
        """Single UI polling loop that applies latest status without flooding callbacks."""
        if self._pending_status is not None:
            self._update_indicators(*self._pending_status)
            self._pending_status = None
        if self.running:
            self.after(100, self._poll_status)

    def _reset_indicators(self):
        self._update_indicators(False, False, False, False)

    def _toggle_led(self, led_num):
        if not self.connected or not self._handshake_ok:
            self._log("Not connected!")
            return

        if led_num == 1:
            cmd = "L1:OFF" if self.led1_state else "L1:ON"
        else:
            cmd = "L2:OFF" if self.led2_state else "L2:ON"
        self._send(cmd, repeats=1)
        self._log(f"Sent: {cmd}")

    def _log(self, msg):
        self.log_box.configure(state="normal")
        timestamp = time.strftime("%H:%M:%S")
        self.log_box.insert("end", f"[{timestamp}] {msg}\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _log_serial(self, msg):
        self.serial_box.configure(state="normal")
        timestamp = time.strftime("%H:%M:%S")
        self.serial_box.insert("end", f"[{timestamp}] {msg}\n")
        self.serial_box.see("end")
        self.serial_box.configure(state="disabled")

    def _on_close(self):
        self.running = False
        self.connected = False
        if self.serial_conn and self.serial_conn.is_open:
            try:
                self.serial_conn.write(("DISCONNECT\n").encode("utf-8"))
            except Exception:
                pass
            try:
                self.serial_conn.close()
            except Exception:
                pass
        self.destroy()


if __name__ == "__main__":
    app = STM32GUI()
    app.mainloop()
